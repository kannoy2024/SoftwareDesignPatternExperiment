package mvc.minimvc;

public class SimpleVIew {
	public String sendData() {
		return "测试信息";
	}
	public void displayMsg(String s)
	{
		System.out.println(s);
	}
}
