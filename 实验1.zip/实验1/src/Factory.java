public interface Factory {
    public Operation createOperation();
}
