//This is the super class in the factory class hierarchy PolicyProducer
package cn.edu.bbc.computer;


public interface PolicyProducer
{
    public AutoInsurance getInsurObj();
}
