//This is the super class in the product class hierarchy AutoInsurance
package cn.edu.bbc.computer;


public interface AutoInsurance {
   abstract String getInfo();
}
