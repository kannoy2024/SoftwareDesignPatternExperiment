public class Add extends Operation{

    @Override
    public int getResult() {
        // TODO Auto-generated method stub
        return getA()+getB();
    }
    
}
